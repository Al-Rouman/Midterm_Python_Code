#problem 03

import numpy

a = numpy.array([[2,4,6], [1,3,5],[7,9,11]])
b = numpy.array([[8,5,2], [7,4,1],[6,3,0]])

print ("The element addition of matrix is : ")
print (numpy.add(a,b))

print ("The element multiply  of matrix is : ")
print (numpy.dot(a,b))

print ("The element multiply  of matrix is : ")
print (numpy.multiply(a,b))