tuples = [(1, 'a'), (2, 'b'), (3, 'c')]
dictionary = dict(tuples)
sorted_dict = dict(sorted(dictionary.items()))
print("Sorted dictionary:", sorted_dict)
