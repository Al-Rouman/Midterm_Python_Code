string =input("enter string: ")

print("Reversed string: ",string[::-1])
