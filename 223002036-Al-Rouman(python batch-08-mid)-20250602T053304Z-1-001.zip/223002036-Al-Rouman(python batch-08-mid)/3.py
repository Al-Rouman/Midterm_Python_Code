multiply = input("enter an arithmetic expression: ")

result = eval(multiply)

print ("Result: ",result )
