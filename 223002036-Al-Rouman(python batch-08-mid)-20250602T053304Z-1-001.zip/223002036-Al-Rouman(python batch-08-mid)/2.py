a = input("enter something: ")

print("data type=",type(eval(a)))