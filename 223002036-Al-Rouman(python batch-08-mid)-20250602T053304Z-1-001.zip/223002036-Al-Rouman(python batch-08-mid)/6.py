import  random

num_guess = random.randint(1,100)
attempts =  5
print("Guess number Between 1 to 100 , you have 5 attempt")

while attempts> 0:
    guess = int(input("Enter your guess: "))
    if guess == num_guess:
        print(" u low ")
        break
    elif guess < num_guess:
         print("Too high")
    attempts -= 1

if attempts == 0:
   print(f"sorry, you are end of attempts. number is {num_guess}.")