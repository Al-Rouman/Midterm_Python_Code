nnum = int(input("enter number:"))

is_prime = True

if nnum < 2:
    is_prime = False

else:
    for i in range(2,int(nnum**0.5)+1):
        if nnum % i == 0:
            is_prime = False
            break

print(f"{nnum} is {'a prome number' if is_prime else 'not prime number '}.")